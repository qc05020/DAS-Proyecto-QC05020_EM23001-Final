from flask import Flask #Este es el archivo principal, desde aquí se arranca todo el sistema.
from routes.auth_routes import auth_bp
from routes.main_routes import main_bp

app = Flask(__name__)
app.secret_key = 'clave_secreta_segura'

# Registrar los blueprints (rutas)
app.register_blueprint(auth_bp)
app.register_blueprint(main_bp)

if __name__ == '__main__':
    app.run(debug=True)
#Este archivo crea la app Flask, registra las rutas (módulos) y la lanza en modo desarrollo