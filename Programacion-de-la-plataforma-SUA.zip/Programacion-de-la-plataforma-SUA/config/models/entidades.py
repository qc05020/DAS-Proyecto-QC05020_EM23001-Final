#Aquí van las clases en POO del sistema (Usuario, Materia, Nota)
class Usuario:
    def __init__(self, carnet, nombre, usuario, contrasena, rol):
        self.carnet = carnet
        self.nombre = nombre
        self.usuario = usuario
        self.contrasena = contrasena
        self.rol = rol

class Materia:
    def __init__(self, id_materia, nombre, codigo):
        self.id_materia = id_materia
        self.nombre = nombre
        self.codigo = codigo

class Nota:
    def __init__(self, id_nota, carnet, id_materia, nota_final):
        self.id_nota = id_nota
        self.carnet = carnet
        self.id_materia = id_materia
        self.nota_final = nota_final
#Cada clase representa una tabla y sus atributos, usando POO