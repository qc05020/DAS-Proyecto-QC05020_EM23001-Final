#Aquí se configura la conexión a MySQL
import pymysql

def obtener_conexion():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='tu_contraseña',
        database='historial_academico',
        cursorclass=pymysql.cursors.DictCursor
    )
