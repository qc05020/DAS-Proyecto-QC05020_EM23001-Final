#Maneja el inicio de sesión y cierre de sesión
from flask import Blueprint, render_template, request, redirect, url_for, session
from config.conexion import obtener_conexion

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/')
def login():
    return render_template('login.html')

@auth_bp.route('/login', methods=['POST'])
def validar_login():
    usuario = request.form['usuario']
    contrasena = request.form['contrasena']

    conexion = obtener_conexion()
    with conexion.cursor() as cursor:
        cursor.execute("SELECT * FROM usuarios WHERE usuario=%s AND contrasena=%s", (usuario, contrasena))
        resultado = cursor.fetchone()

    if resultado:
        session['usuario'] = resultado['usuario']
        session['rol'] = resultado['rol']
        return redirect(url_for('main.dashboard'))
    else:
        return "Credenciales inválidas"

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))
